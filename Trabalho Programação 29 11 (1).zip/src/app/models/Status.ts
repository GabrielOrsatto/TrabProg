export enum Status {
    SIM = "SIM",
    NAO = "NAO"
   }