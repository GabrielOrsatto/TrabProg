export enum Tipo {
    BRANCA = "BRANCA",
    FOGO = "FOGO"
    }